﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void kiszamolGomb_Click(object sender, RoutedEventArgs e)
        {
            double eredmeny = 0;
            double mennyiseg = Convert.ToDouble(adattbox.Text);
            double sebesseg = Convert.ToDouble(slValue.Value);
            if (atvSeb.Text == "MB/s" && adatmenny.Text == "MB")
            {
                eredmeny = mennyiseg / sebesseg;
                eredmenytextbox.Text = Convert.ToString(Math.Round(eredmeny));
            }
            if (atvSeb.Text == "KB/s" && adatmenny.Text == "KB")
            {
                eredmeny = mennyiseg / sebesseg;
                eredmenytextbox.Text = Convert.ToString(Math.Round(eredmeny));
            }
            if (atvSeb.Text == "GB/s" && adatmenny.Text == "GB")
            {
                eredmeny = mennyiseg / sebesseg;
                eredmenytextbox.Text = Convert.ToString(Math.Round(eredmeny));
            }


            if (atvSeb.Text == "MB/s" && adatmenny.Text == "KB")
            {
                mennyiseg = mennyiseg * 1000;
                eredmeny = mennyiseg / sebesseg;
                eredmenytextbox.Text = Convert.ToString(Math.Round(eredmeny));
            }
            if (atvSeb.Text == "MB/s" && adatmenny.Text == "GB")
            {
                mennyiseg = mennyiseg * 1000;
                eredmeny = mennyiseg / sebesseg;
                eredmenytextbox.Text = Convert.ToString(Math.Round(eredmeny));
            }
            if (atvSeb.Text == "MB/s" && adatmenny.Text == "TB")
            {
                mennyiseg = mennyiseg * 1000000;
                eredmeny = mennyiseg / sebesseg;
                eredmenytextbox.Text = Convert.ToString(Math.Round(eredmeny));
            }


            if (atvSeb.Text == "KB/s" && adatmenny.Text == "GB")
            {
                mennyiseg = mennyiseg * 1000;
                eredmeny = mennyiseg / sebesseg;
                eredmenytextbox.Text = Convert.ToString(Math.Round(eredmeny));
            }
            if (atvSeb.Text == "KB/s" && adatmenny.Text == "MB")
            {
                mennyiseg = mennyiseg * 0.001;
                eredmeny = mennyiseg / sebesseg;
                eredmenytextbox.Text = Convert.ToString(Math.Round(eredmeny));
            }
            if (atvSeb.Text == "KB/s" && adatmenny.Text == "TB")
            {
                mennyiseg = mennyiseg * 1000000000;
                eredmeny = mennyiseg / sebesseg;
                eredmenytextbox.Text = Convert.ToString(Math.Round(eredmeny));
            }

            if (atvSeb.Text == "GB/s" && adatmenny.Text == "TB")
            {
                mennyiseg = mennyiseg * 1000;
                eredmeny = mennyiseg / sebesseg;
                eredmenytextbox.Text = Convert.ToString(Math.Round(eredmeny));
            }
            if (atvSeb.Text == "GB/s" && adatmenny.Text == "MB")
            {
                mennyiseg = mennyiseg * 0.001;
                eredmeny = mennyiseg / sebesseg;
                eredmenytextbox.Text = Convert.ToString(Math.Round(eredmeny));
            }
            if (atvSeb.Text == "GB/s" && adatmenny.Text == "KB")
            {
                mennyiseg = mennyiseg * 0.000001;
                eredmeny = mennyiseg / sebesseg;
                eredmenytextbox.Text = Convert.ToString(Math.Round(eredmeny));
            }


        }

        private void adattbox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void slValue_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {

        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void atvSeb_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void adatmenny_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void eredmenytextbox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
        public void atvaltott()
        {
            double eredmeny = Convert.ToDouble(eredmenytextbox.Text);
            double orak = Math.Floor(eredmeny / 3600);
            eredmeny %= 3600;
            double percek = Math.Floor(eredmeny / 60);
            double masodpercek = eredmeny % 60;
            veglegestbox.Text = ($"{orak} óra, {percek} perc {masodpercek} masodperc");
        }
    }
}
